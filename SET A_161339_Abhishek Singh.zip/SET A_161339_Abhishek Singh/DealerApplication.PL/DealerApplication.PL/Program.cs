﻿using DealerApplication.BL;
using DealerApplication.Entities;
using DealerApplication.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerApplication.PL
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter Your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddDealer();
                            break;

                        case 2:
                            SearchDealer();
                            break;

                        case 3:
                            DisplayDealerList();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice...");
                            break;

                    }
                } while (choice != -1);

            }
            catch (SystemException sys)
            {

                throw new DealerException(sys.Message);
            }

        }
        private static void DisplayDealerList()
        {
            try
            {

                DealerBL gpbl = new DealerBL();
                List<Dealer> dealerList = gpbl.GetAllDealers();
                Dealer d = new Dealer();
                if (dealerList != null)
                {
                    Console.WriteLine("=========================================================================");
                    Console.WriteLine("DealerID\tDealerName\tDealerAddress\tDealerPhoneNo\tDealerStatus\tDealerProductCategory");
                    Console.WriteLine("=========================================================================");
                    foreach (Dealer dealer in dealerList)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", dealer.DealerId, dealer.DealerName, dealer.DealerAddress, dealer.PhoneNo, dealer.DealerProductCategory, dealer.DealerStatus,dealer.DealerEmail);
                    }
                    Console.WriteLine("==========================================================================");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private static void SearchDealer()
        {
            try
            {
                int searchDealerId;
                Console.WriteLine("Enter Dealer ID of Which you have to search details:");
                searchDealerId = Convert.ToInt32(Console.ReadLine());
                DealerBL dealerBL = new DealerBL();
                Dealer gp = dealerBL.SearchDealerByID(searchDealerId);
                if (gp != null)
                {
                    Console.WriteLine("==========================================================================================");
                    Console.WriteLine("DealerID\t\tDealerName\t\tDealerProductCategory\t\tDealerPhoneno\t\tDealerEmailId\t\tDealerStatus");
                    Console.WriteLine("==========================================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", gp.DealerId, gp.DealerName, gp.PhoneNo, gp.DealerProductCategory, gp.DealerStatus, gp.DealerEmail);
                    Console.WriteLine("==========================================================================================");
                }
                else
                {
                    Console.WriteLine("Visitor's Details Not Available");
                }
            }
            catch (SystemException sys)
            {

                throw new DealerException(sys.Message);
            }
        }
        private static void AddDealer()
        {
            try
            {
                DealerBL dealerBL = new DealerBL();
                Dealer dealer = new Dealer();
                Random r = new Random();
                dealer.DealerId = r.Next(1000, 9999);
                Console.WriteLine("Enter Dealer ID:");
                dealer.DealerId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Dealer Name:");
                dealer.DealerName = Console.ReadLine();
                Console.WriteLine("Enter DealerProductCategory");
                dealer.DealerProductCategory = (Console.ReadLine());
                Console.WriteLine("Enter Phone Number:");
                dealer.PhoneNo = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter Dealer Status:");
                dealer.DealerStatus = Console.ReadLine();
                Console.WriteLine("Enter Dealer Emailid :");
                dealer.DealerEmail = Console.ReadLine();
                bool dealerAdded = dealerBL.AddDealer(dealer);
                if (dealerAdded)
                {
                    Console.WriteLine("Dealer Added" + dealer.DealerId);
                }
                else
                {
                    Console.WriteLine("Dealer not Added");
                }

            }
            catch (DealerException sys)
            {

                Console.WriteLine(sys.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("1. Add Dealer");
            Console.WriteLine("2. Search Dealer");
            Console.WriteLine("3. Display Dealer's List");
        }


    }

}
