﻿using DealerApplication.Entities;
using DealerApplication.Exceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DealerApplication.Dal
{
    public class DealerDal
    {
        static List<Dealer> DealerList = new List<Dealer>();
        public DealerDal()
        {
        }


        //=========: Adding Dealer :=============
        public bool AddDealer(Dealer dealer)
        {
            bool dealerAdded = false;
            try
            {
                DealerList.Add(dealer);
                dealerAdded = true;
            }
            catch (SystemException sys)
            {

                throw new DealerException(sys.Message);
            }
            return dealerAdded;
        }
        public List<Dealer> GetAllDealer()
        {
            return DealerList;
        }
        public Dealer SearchDealerDAL(int searchDealerID)
        {
            try
            {

                Dealer searchDealer = DealerList.Find(d => d.DealerId == searchDealerID);
                return searchDealer;
            }
            catch (SystemException ex)
            {
                throw new DealerException(ex.Message);
            }

        }
        public static void SerializeData(List<Dealer> d1)
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, d1);
            fileStream.Close();
        }

        public static void DeserializeData()
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            List<Dealer> e1 = (List<Dealer>)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();

        }

    }
}
