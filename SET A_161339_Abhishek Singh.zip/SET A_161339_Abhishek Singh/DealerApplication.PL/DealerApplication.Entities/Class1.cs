﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerApplication.Entities
{
    [Serializable]
    public class Dealer
    {
        public int DealerId { get; set; }
        public  string DealerName { get; set; }
        public string DealerAddress { get; set; }
        public string DealerEmail{ get; set; }
        public string PhoneNo { get; set; }
        public  string DealerStatus { get; set; }
        public string DealerProductCategory { get; set; }


        public Dealer()
        {
            DealerId = 0;
            DealerName = string.Empty;
            DealerAddress = string.Empty;
            DealerEmail = string.Empty;
            DealerProductCategory = string.Empty;
            PhoneNo = string.Empty;
            DealerStatus = string.Empty;
        }

    }
    

    public enum DealerStatus { Active, Inactive }
    public enum DealerProductCategory { Grocery, BakeryProducts, Vegetables }
}
