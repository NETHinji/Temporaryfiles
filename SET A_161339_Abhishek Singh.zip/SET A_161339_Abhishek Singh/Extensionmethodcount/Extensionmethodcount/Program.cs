﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensionmethodcount
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a senetence");
            string inputstr = Console.ReadLine();
            int numberofword = inputstr.WordCount();
            Console.WriteLine("Total no of word in a string is:"+numberofword);
            Console.ReadKey(true);

        }
    }
}
