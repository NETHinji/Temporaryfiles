﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensionmethodcount
{
    public static class StringExtension
    {
        public static int WordCount(this string s)
        {
            int count = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] != ' ')
                {
                    if ((i + 1) == s.Length)
                    {
                        count++;
                    }
                    else
                    {
                        if (s[i + 1] == ' ')
                        {
                            count++;
                        }
                    }
                }
            }
            return count;
        }
    }
}
