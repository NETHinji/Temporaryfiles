﻿var session = 0;
function UserLogIn() {
    var userid = document.getElementById("userid").value;
    var password = document.getElementById("pass").value;

    $.getJSON("UserInfo.json", function (data){
        if (userid == data.UserId && password == data.Password) {
           
            session = 1;
           // Response.redirect("another.html");
            window.location.href = "index.html";
            alert("Get started");
            
            
        }
        else {
            alert(" please enter perfect id/ password");
        }
    })

}