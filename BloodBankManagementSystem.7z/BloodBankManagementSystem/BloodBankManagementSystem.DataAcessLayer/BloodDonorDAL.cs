﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;

namespace BloodBankManagementSystem.DataAcessLayer
{
    public class BloodDonorDAL
    {

        static string constr = string.Empty;         //connection string set as empty
        SqlConnection con = null;                    //sql connection object set to null 
        SqlCommand cmd = null;                       //sql command object set to null
        //creating static constructor to initialize the "constr" variable from the app.configue file 
        static BloodDonorDAL()
        {
            constr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        // constructor to set the connection object to the connection string 
        public BloodDonorDAL()
        {
            con = new SqlConnection(constr);
        }



        public bool AddBloodDonor(BloodDonor bb)
        {
            bool result = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspAddBloodDonorDetails";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@BloodDonorId", bb.BloodDonorId);
                cmd.Parameters.AddWithValue("@FirstName", bb.FirstName);
                cmd.Parameters.AddWithValue("@LastName", bb.LastName);
                cmd.Parameters.AddWithValue("@Address", bb.Address);
                cmd.Parameters.AddWithValue("@City", bb.City);
                cmd.Parameters.AddWithValue("@Contact", bb.MobileNo);
                cmd.Parameters.AddWithValue("@BloodGroup", bb.BloodGroup);

                con.Open();
                int noOfAffectedRows = cmd.ExecuteNonQuery();
                if(noOfAffectedRows>0)
                {
                    result = true;
                }

            }
            catch(BloodBankExceptions)
            {
                MessageBox.Show("Invalid data");
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }
    }
}
