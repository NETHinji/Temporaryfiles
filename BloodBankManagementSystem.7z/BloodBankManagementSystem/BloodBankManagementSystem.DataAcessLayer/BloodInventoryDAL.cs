﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BloodBankManagementSystem.Exceptions;
using BloodBankManagementSystem.Entities;
using System.Windows.Forms;

namespace BloodBankManagementSystem.DataAcessLayer
{
   public class BloodInventoryDAL
    {
        static string constr = string.Empty;         //connection string set as empty
        SqlConnection con = null;                    //sql connection object set to null 
        SqlCommand cmd = null;                       //sql command object set to null
        //creating static constructor to initialize the "constr" variable from the app.configue file 
        static BloodInventoryDAL()
        {
            constr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        // constructor to set the connection object to the connection string 
        public BloodInventoryDAL()
        {
            con = new SqlConnection(constr);
        }

        public DataTable GetAllBloodBankName()
        {
            DataTable bloodBankName = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspGetAllBloodBankName";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    bloodBankName = new DataTable();
                    bloodBankName.Load(dr);
                }



            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return bloodBankName;
        }


        public DataTable GetAllHospitalName()
        {
            DataTable HospitalName = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspGetAllHospitalName";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    HospitalName = new DataTable();
                    HospitalName.Load(dr);
                }



            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return HospitalName;
        }

    }
}
