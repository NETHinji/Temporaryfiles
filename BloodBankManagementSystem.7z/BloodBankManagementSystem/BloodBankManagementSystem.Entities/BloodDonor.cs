﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
   public class BloodDonor
    {
        private int bloodDonorId;
        private string firstName;
        private string lastName;
        private string address;
        private string city;
        private long mobileNo;
        private string bloodGroup;

        public int BloodDonorId { get => bloodDonorId; set => bloodDonorId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Address { get => address; set => address = value; }
        public string City { get => city; set => city = value; }
        public long MobileNo { get => mobileNo; set => mobileNo = value; }
        public string BloodGroup { get => bloodGroup; set => bloodGroup = value; }
    }
}
