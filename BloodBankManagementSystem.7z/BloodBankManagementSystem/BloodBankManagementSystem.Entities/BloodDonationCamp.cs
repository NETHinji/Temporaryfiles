﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
    class BloodDonationCamp
    {
        private int bloodDonationCampId;
        private string campName;
        private string address;
        private string city;
        private int bloodBankId;
        private DateTime campStartDate;
        private DateTime campEndDate;

        public int BloodDonationCampId { get => bloodDonationCampId; set => bloodDonationCampId = value; }
        public string CampName { get => campName; set => campName = value; }
        public string Address { get => address; set => address = value; }
        public string City { get => city; set => city = value; }
        public int BloodBankId { get => bloodBankId; set => bloodBankId = value; }
        public DateTime CampStartDate { get => campStartDate; set => campStartDate = value; }
        public DateTime CampEndDate { get => campEndDate; set => campEndDate = value; }
    }
}
