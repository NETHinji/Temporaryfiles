﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
    class Hospital
    {
        private int hospitalId;
        private string hospitalName;
        private string address;
        private string city;
        private long contactNo;

        public int HospitalId { get => hospitalId; set => hospitalId = value; }
        public string HospitalName { get => hospitalName; set => hospitalName = value; }
        public string Address { get => address; set => address = value; }
        public string City { get => city; set => city = value; }
        public long ContactNo { get => contactNo; set => contactNo = value; }
    }
}
