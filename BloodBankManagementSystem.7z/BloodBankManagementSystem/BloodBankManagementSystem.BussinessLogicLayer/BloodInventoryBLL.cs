﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BloodBankManagementSystem.DataAcessLayer;

namespace BloodBankManagementSystem.BussinessLogicLayer
{
   public class BloodInventoryBLL
    {
        public DataTable GetAllBloodBankName()
        {
            BloodInventoryDAL bid = new BloodInventoryDAL();
            return bid.GetAllBloodBankName();


        }

        public DataTable GetAllHospitalName()
        {
            BloodInventoryDAL bid = new BloodInventoryDAL();
            return bid.GetAllHospitalName();


        }

    }
}
