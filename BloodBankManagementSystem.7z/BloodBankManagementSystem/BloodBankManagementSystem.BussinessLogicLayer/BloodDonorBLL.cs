﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;
using BloodBankManagementSystem.DataAcessLayer;

namespace BloodBankManagementSystem.BussinessLogicLayer
{
    public class BloodDonorBLL
    {
        public bool AddBloodDonor(BloodDonor bd)
        {
               BloodDonorDAL bdd = new BloodDonorDAL();
                return bdd.AddBloodDonor(bd);
            
            
        }
        
    }
}
