﻿using BloodBankManagementSystem.DataAcessLayer;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;
using System;
using System.Data;
using System.Text;
using System.Windows.Forms;


namespace BloodBankManagementSystem.BussinessLogicLayer
{

    public class BloodBankBLL
    {

        private static bool ValidateDetails(BloodBank bb)
        {
            StringBuilder sb = new StringBuilder();
            bool isvalid = true;
            if (bb.BloodBankId <= 0)
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "Invalid BloodBank ID");

            }
            if (bb.BloodBankName == string.Empty)                
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "BloodBank Name Required");

            }
            if (bb.Address == string.Empty)
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "Address Required");

            }

            if (bb.City == string.Empty)
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "City Name Required");

            }
            if (bb.UserId == string.Empty)
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "UserName Required");

            }
            if (bb.Password == string.Empty)
            {
                isvalid = false;
                sb.Append(Environment.NewLine + "BloodBank Name Required");

            }
            if (bb.ContactNumber<7000000000 || bb.ContactNumber>9999999999 )
            {
                isvalid = false;
                //sb.Append(Environment.NewLine + "mobile number should starts from '7' & '8'&'9' && length must be 10 digit long");
                MessageBox.Show("mobile number should starts from '7' & '8'&'9' && length must be 10 digit long");
            }
            
            //if (isvalid == false)
            //    throw new BloodBankExceptions(sb.ToString());
            return isvalid;
        }


        //creating object of data Acess Layer globally
        BloodBankDAL bbd = new BloodBankDAL();
        //Method for varifying UserName and Password
        public bool IsLogin(string userName, string password) 
            
        {
            bool isTrue = false;
            try
            {



                BloodBankDAL bbd = new BloodBankDAL();
                isTrue = bbd.IsLogin(userName, password);



            }
            catch(BloodBankExceptions ex)

            {
                MessageBox.Show("Inavalid Data"+ex);
            }
            return isTrue;

        }

        //method for adding details of blood bank
        public int AddBloodBankDetails(BloodBank bb)
        {
            int result = 0;
            bool isValid = ValidateDetails(bb);
            if (isValid)
            {
                try
                {

                    BloodBankDAL bbd = new BloodBankDAL();
                    result = bbd.AddBloodBankDetails(bb);
                }
                catch (BloodBankExceptions ex)
                {
                    MessageBox.Show("invalid data" + ex);
                }
            }
            else
                MessageBox.Show("eneter correct data");
            return result;

        }

        //method for displaying Blood bank details
        public DataTable Display()
        {
            DataTable dt = null;
            try
            {
                BloodBankDAL dal = new BloodBankDAL();
               dt= dal.Display();
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            return dt;
        }

        //method to get data in combobox of blood bank Id
        public DataTable GetAllBloodBankName()
        {
            DataTable bloodBankName = null;
            try
            {
                BloodBankDAL dal = new BloodBankDAL();
                bloodBankName = dal.GetAllBloodBankName();
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            return bloodBankName;


        }

        //method for search the blood bank details based on blood banki id


        public BloodBank Search(string selectedName)
        {
            BloodBank bb = null;
            try
            {
                BloodBankDAL bbd = new BloodBankDAL();
                bb = bbd.Search(selectedName);
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            return bb;

        }


        //method for update blood bank details
        public bool UpdateBloodBankDetails(BloodBank bb)
        {
            return bbd.UpdateBloodBankDetails(bb);
       

        }


    }

    
    
    
}
