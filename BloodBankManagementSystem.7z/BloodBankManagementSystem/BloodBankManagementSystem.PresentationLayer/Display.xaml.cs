﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for Display.xaml
    /// </summary>
    public partial class Display : Window
    {
        public Display()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            LoginPage l = new LoginPage();
            l.Show();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

            BloodBankAdd_view bbav = new BloodBankAdd_view();
            bbav.Show();
            this.Close();


        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            BloodBankAdd_view bbav = new BloodBankAdd_view();
            bbav.Show();
            this.Close();

        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            BloodInventory bi = new BloodInventory();
            bi.Show();
            this.Close();
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            BloodDonor bd = new BloodDonor();
            bd.Show();
            this.Close();
        }
    }
}
