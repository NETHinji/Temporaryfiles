﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.BussinessLogicLayer;
using BloodBankManagementSystem.Exceptions;
namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for BloodDonor.xaml
    /// </summary>
    public partial class BloodDonor : Window
    {
        public BloodDonor()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            BloodBankAdd_view bbav = new BloodBankAdd_view();
            bbav.Show();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            BloodInventory bi = new BloodInventory();
            bi.Show();
            this.Close();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BloodBankManagementSystem.Entities.BloodDonor bd = new Entities.BloodDonor
                {
                    BloodDonorId = int.Parse(txtBloodDonorId.Text),
                    FirstName=txtFirstName.Text,
                    LastName=txtLastName.Text,
                    Address=txtAddress.Text,
                    City=txtCity.Text,
                    MobileNo=long.Parse(txtContact.Text),
                    BloodGroup=txtBloodGroup.Text
                 
                };


                BloodDonorBLL bdb = new BloodDonorBLL();
              bool result=  bdb.AddBloodDonor(bd);  
                
                if(result)
                {
                    MessageBox.Show("Added Sucessfully");
                    BloodDonorDonationDetails bddd = new BloodDonorDonationDetails();
                    bddd.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nope");
                }
            
            }
            catch(BloodBankExceptions ex)
            {
                MessageBox.Show("Invalid data" +ex);
            }
            catch(Exception )
            {
                MessageBox.Show("Invalid data");
            }
        }
    }
}
