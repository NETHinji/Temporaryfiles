﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BussinessLogicLayer;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;
using System.Data;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for BloodBankEdit_delete.xaml
    /// </summary>
    public partial class BloodBankEdit_delete : Window
    {
        public BloodBankEdit_delete()
        {
            InitializeComponent();



        }

        private void cmbBloodBankId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


            // string selectedName = cmbBloodBankName.ToString();
            string selectedName = cmbBloodBankName.SelectedValue.ToString();
            BloodBankBLL bbb = new BloodBankBLL();
            BloodBank bb = bbb.Search(selectedName);
            if (bb != null)
            {
                lblBloodbankId.Content = bb.BloodBankId.ToString();
                txtAddress.Text = bb.Address;
                txtCity.Text = bb.City;
                txtContactNo.Text = bb.ContactNumber.ToString();
                txtUserName.Text = bb.UserId;
                txtPassword.Password = txtPassword.ToString();

            }
            else
                MessageBox.Show("select your choice");



        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            GetAllBloodBankName();
           




        }


        public void GetAllBloodBankName()
        {
            BloodBankBLL bbb = new BloodBankBLL();
            DataTable bloodBankName = bbb.GetAllBloodBankName();
            if (bloodBankName == null)
            {
                MessageBox.Show("nothing to show");
            }
            else
            {
                string[] result = new string[bloodBankName.Rows.Count];


                for (int i = 0; i < bloodBankName.Rows.Count; i++)
                {
                    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                    {
                        result[i] = bloodBankName.Rows[i][j].ToString();
                        cmbBloodBankName.Items.Remove(result[i]);
                    }
                }
                for (int i = 0; i < bloodBankName.Rows.Count; i++)
                {
                    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                    {
                        result[i] = bloodBankName.Rows[i][j].ToString();
                        cmbBloodBankName.Items.Add(result[i]);
                    }
                }
            }

        }




        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            BloodBank bb = new BloodBank
            {
                
                BloodBankName = cmbBloodBankName.Text,
                Address = txtAddress.Text,
                City = txtCity.Text,
                ContactNumber = long.Parse(txtContactNo.Text),
                UserId = txtUserName.Text,
                Password = txtPassword.Password




            };

            try
            {
                BloodBankBLL bbb = new BloodBankBLL();
                bool affectedRows = bbb.UpdateBloodBankDetails(bb);
                if (affectedRows)
                {
                    MessageBox.Show("Sucessfully saved" + affectedRows);
                }
                else
                    MessageBox.Show("you entered invalid data");
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            LoginPage l = new LoginPage();
            l.Show();
            this.Close();

        }

        
    }

}
