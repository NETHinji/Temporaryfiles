﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BussinessLogicLayer;
using System.Data;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for BloodInventory.xaml
    /// </summary>
    public partial class BloodInventory : Window
    {
        public BloodInventory()
        {
            InitializeComponent();
        }

        private void ToBloodBank_Click(object sender, RoutedEventArgs e)
        {
            cmbTo.Items.Clear();
            groupBox1.Visibility = Visibility.Visible;
            GetAllBloodBankName();
            
        }


        public void GetAllBloodBankName()
        {
            BloodInventoryBLL bi = new BloodInventoryBLL();
            DataTable bloodBankName = bi.GetAllBloodBankName();
            if (bloodBankName == null)
            {
                MessageBox.Show("nothing to show");
            }
            else
            {
                cmbFrom.Items.Clear();

                string[] result = new string[bloodBankName.Rows.Count];


                //for (int i = 0; i < bloodBankName.Rows.Count; i++)
                //{
                //    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                //    {
                //        result[i] = bloodBankName.Rows[i][j].ToString();
                //        cmbFrom.Items.Remove(result[i]);
                //        cmbTo.Items.Remove(result[i]);
                //    }
                //}
                for (int i = 0; i < bloodBankName.Rows.Count; i++)
                {
                    for (int j = 0; j < bloodBankName.Columns.Count; j++)
                    {
                        result[i] = bloodBankName.Rows[i][j].ToString();
                        cmbFrom.Items.Add(result[i]);
                        cmbTo.Items.Add(result[i]);
                    }
                }
            }

        }

        private void cmbFrom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string s = cmbFrom.Text.ToString();
            cmbTo.Items.Remove(s);
        }

        private void ToHospital_Click(object sender, RoutedEventArgs e)
        {
            groupBox1.Visibility = Visibility.Visible;
            GetAllBloodBankName();
            GetAllHospitalName();
        }

        public void GetAllHospitalName()
        {
            BloodInventoryBLL bi = new BloodInventoryBLL();
            DataTable HospitalName = bi.GetAllHospitalName();
            if (HospitalName == null)
            {
                MessageBox.Show("nothing to show");
            }
            else
            {
                string[] result = new string[HospitalName.Rows.Count];

                cmbTo.Items.Clear();
                //for (int i = 0; i < HospitalName.Rows.Count; i++)
                //{
                //    for (int j = 0; j < HospitalName.Columns.Count; j++)
                //    {
                //        result[i] = HospitalName.Rows[i][j].ToString();
                //        cmbTo.Items.Remove(result[i]);
                        
                //    }
                //}
                for (int i = 0; i < HospitalName.Rows.Count; i++)
                {
                    for (int j = 0; j < HospitalName.Columns.Count; j++)
                    {
                        result[i] = HospitalName.Rows[i][j].ToString();
                        
                        cmbTo.Items.Add(result[i]);

                    }
                }
            }

        }
    }
}
