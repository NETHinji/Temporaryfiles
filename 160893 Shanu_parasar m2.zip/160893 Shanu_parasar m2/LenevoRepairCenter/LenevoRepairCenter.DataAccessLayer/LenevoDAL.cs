﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using LenevoRepairCenter.Entities;
using LenevoRepairCenter.LenevoException;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace LenevoRepairCenter.DataAccessLayer
{
    public class LenevoDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static LenevoDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public LenevoDAL()
        {
            con = new SqlConnection(conStr);

        }

        public int  AddDetails(Lenevo l)
        {
            int result = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu3.uspAddLenevo";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ServiceId", l.ServiceID);
                cmd.Parameters.AddWithValue("@DateNow", l.DateNow);
                cmd.Parameters.AddWithValue("@OwnerName",l.OwnerName);
                cmd.Parameters.AddWithValue("@Contact", l.Contact);
                cmd.Parameters.AddWithValue("@DeviceType", l.DeviceType);
                cmd.Parameters.AddWithValue("@SerialNo", l.SerialNo);
                cmd.Parameters.AddWithValue("@Issue", l.IssueDescription);
                con.Open();
                 result = cmd.ExecuteNonQuery();


            }
            catch(LenevoExceptions)
            {

                throw;
            }
            catch(SystemException ex)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;

        }
        public DataTable Display()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu3.uspDisplay";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (LenevoExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;


        }
    }
}
