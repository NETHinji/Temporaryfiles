﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenevoRepairCenter.LenevoException
{
    public class LenevoExceptions:ApplicationException
    {
        public LenevoExceptions():base()
        {


        }

        public LenevoExceptions(string message): base(message)
        {


        }
        public LenevoExceptions(string message,Exception innerException) : base(message, innerException)
        {
        }
    }
}
