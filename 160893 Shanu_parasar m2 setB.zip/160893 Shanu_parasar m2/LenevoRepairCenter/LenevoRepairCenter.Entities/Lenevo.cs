﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LenevoRepairCenter.Entities
{
    public class Lenevo
    {
        public string ServiceID { get; set; }
        public string OwnerName { get; set; }
        public long Contact { get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDescription { get; set; }
        public DateTime DateNow { get; set; }
    }
    public enum PossibleDeviceType
    {
        Laptop=0,
        Mobile=1,
        Desktop=2

    }
}
