﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LenevoRepairCenter.BusinessLogicLayer;
using LenevoRepairCenter.Entities;
using LenevoRepairCenter.LenevoException;

namespace LenevoRepairCenter.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            cmbDeviceType.ItemsSource = Enum.GetValues(typeof(PossibleDeviceType));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lenevo l = new Lenevo
                {
                    ServiceID = txtServiceId.Text,
                    DateNow = datePicker1.SelectedDate.Value.Date,
                    OwnerName = txtOwnerName.Text,
                    Contact = long.Parse(txtContact.Text),
                    DeviceType = cmbDeviceType.Text,
                    SerialNo = txtSerialNo.Text,
                    IssueDescription = txtDesc.Text



                };
                LenevoBLL bll = new LenevoBLL();
                int a = bll.AddDetails(l);
                if (a != 0)
                {
                    MessageBox.Show("Added SuccessFully");
                }

                DataTable dt = bll.Display();
                if (dt != null)
                {
                    dgDisplay.ItemsSource = dt.DefaultView;
                }
                else
                {

                    MessageBox.Show("Table is Empty");
                }





            }
            catch(LenevoExceptions)
            {

                throw;
            }

        }
    }
}
