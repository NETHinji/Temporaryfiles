﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LenevoRepairCenter.DataAccessLayer;
using LenevoRepairCenter.Entities;
using LenevoRepairCenter.LenevoException;

namespace LenevoRepairCenter.BusinessLogicLayer
{
    public class LenevoBLL
    {
        public int AddDetails(Lenevo l)
        {
            try
            {
                LenevoDAL dal = new LenevoDAL();
                return dal.AddDetails(l);


            }
            catch(LenevoExceptions)
            {
                throw;
            }


        }
        public DataTable Display()
        {
            try
            {
                LenevoDAL dal = new LenevoDAL();
                return dal.Display();
            }
            catch (LenevoExceptions)
            {
                throw;
            }

        }

    }
}
