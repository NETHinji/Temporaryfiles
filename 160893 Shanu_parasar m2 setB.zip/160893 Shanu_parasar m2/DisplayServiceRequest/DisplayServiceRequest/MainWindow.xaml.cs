﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DisplayServiceRequest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Training_19Sep18_PuneEntities tr = new Training_19Sep18_PuneEntities();
            AddLenevo al = new AddLenevo();
            uspDisplay1_Result usp = new uspDisplay1_Result();
            string s = combox2.Text;


            var Result = from v in tr.AddLenevoes
                         where (v.DeviceType == s)
                        
                         select v;

            dgDisplay.ItemsSource = Result.ToList();

        }
    }
}
