﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeManagementSystem.Entities;
using EmployeeManagementSystem.Exception;
using EmployeeManagementSystem.DataAcessLayer;
using System.Data;

namespace EmployeeManagementSystem.BussinessLogicLayer
{
    public class EmployeeBLL
    {

        public int AddEmployee(Employee emp)
        {
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                return dal.AddEmployee(emp);

            }
            catch (EmployeeException)
            {

                throw;
            }





        }
        public Employee Search(int EmpId)
        {
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                return dal.Search(EmpId);


            }
            catch (EmployeeException)
            {

                throw;
            }

        }

        public bool EditEmployee(Employee emp)
        {
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                return dal.EditEmployee(emp);


            }
            catch (EmployeeException)
            {
                throw;
            }

        }
        public bool DeleteEmployee(int emp)
        {
            //bool result = false;
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                return dal.DeleteEmployee(emp);


            }
            catch (EmployeeException)
            {
                throw;

            }
        }

        public DataTable Display()
        {
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                return dal.Display();

            }
            catch(EmployeeException)
            {
                throw;
            }



        }





    }        

       
}
