﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using EmployeeManagementSystem.Entities;
using EmployeeManagementSystem.Exception;
using System.Data;

namespace EmployeeManagementSystem.DataAcessLayer
{
    public class EmployeeDAL
    {
        static string conStr = string.Empty;
        SqlConnection con=null;
        SqlCommand cmd = null;

        static EmployeeDAL()
        {
            conStr= ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }
        public EmployeeDAL()
        {
            con = new SqlConnection(conStr);

        }

        public int AddEmployee(Employee emp)
        {
            int eid = 0;
            try
            {
                
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu2.uspAddEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EId", SqlDbType.Int);
                cmd.Parameters["@EId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@EFname",emp.FirstName);
                cmd.Parameters.AddWithValue("@ELname", emp.Lastname);
                cmd.Parameters.AddWithValue("@ESalary", emp.Salary);
                cmd.Parameters.AddWithValue("@EEmail", emp.EmailId);
                cmd.Parameters.AddWithValue("@EEType", emp.EmailType);
                cmd.Parameters.AddWithValue("@EContact", emp.ContactNumber);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                eid = int.Parse(cmd.Parameters["@EId"].Value.ToString());

            }
            catch(EmployeeException)
            {
                throw;

            }
            
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }

            }


            return eid;




        }

        public Employee Search(int EmpId)
        {
            Employee employee = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu2.uspSearchEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpId", EmpId);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    employee = new Employee
                    {
                        EmployeeID=int.Parse(dr["EmpId"].ToString()),
                        FirstName=dr["EmpFName"].ToString(),
                        Lastname = dr["EmpLName"].ToString(),
                        Salary = decimal.Parse(dr["EmpSalary"].ToString()),
                        EmailId = dr["EmpEmail"].ToString(),
                        EmailType = dr["EmpEmailtype"].ToString(),
                        ContactNumber=long.Parse(dr["EmpContact"].ToString())

                    };
                    dr.Close();
                    
                }


            }
            catch(EmployeeException)
            {
                throw;

            }
            catch(SystemException)
            { throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return employee;


        }

        public bool EditEmployee(Employee emp)
        {
            bool result = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu2.uspEditEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EFname", emp.FirstName);
                cmd.Parameters.AddWithValue("@ELname", emp.Lastname);
                cmd.Parameters.AddWithValue("@ESalary", emp.Salary);
                cmd.Parameters.AddWithValue("@EContact", emp.ContactNumber);
                cmd.Parameters.AddWithValue("EId", emp.EmployeeID);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;

                }


            }
            catch(EmployeeException)
            {
                throw;


            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;


        }

        public bool DeleteEmployee(int emp)
        {
            bool result = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu2.uspDeleteEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("EId",emp);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }

            }
            catch(EmployeeException)
            {
                throw;

            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;




        }

        public DataTable Display()
        {
            DataTable dt = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu2.uspDisplayEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }


            }
            catch(EmployeeException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;



        }



    }
}
