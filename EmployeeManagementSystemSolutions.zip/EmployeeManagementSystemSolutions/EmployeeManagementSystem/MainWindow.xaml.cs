﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeManagementSystem.BussinessLogicLayer;
using EmployeeManagementSystem.Entities;
using EmployeeManagementSystem.Exception;

namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    FirstName = txtFirstName.Text,
                    Lastname = txtLastName.Text,
                    Salary = decimal.Parse(txtSalary.Text),
                    EmailId = txtEmail.Text,
                    ContactNumber=long.Parse(txtContact.Text),
                    EmailType=combEmail.Text





                };
                EmployeeBLL bll = new EmployeeBLL();
                int Eid = bll.AddEmployee(emp);
                lblDisplayId.Content = Eid;
                MessageBox.Show("Employee Added Succesfully");
                Search s = new Search();
                s.Show();

            } catch(EmployeeException ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
