﻿using EmployeeManagementSystem.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EmployeeManagementSystem.BussinessLogicLayer;
using EmployeeManagementSystem.Entities;

namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            this.grpbox1.Visibility = Visibility.Visible;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBLL bll = new EmployeeBLL();
                Employee emp =  bll.Search(int.Parse(txtEmpId.Text));
                if(emp!=null)
                {
                    lblEmployeeId.Content = emp.EmployeeID;
                    txtFName.Text = emp.FirstName.ToString();
                    txtLName.Text = emp.Lastname.ToString();
                    txtSalary.Text = emp.Salary.ToString();
                    txtContact.Text = emp.ContactNumber.ToString();
                    lblEmail.Content = (emp.EmailId + emp.EmailType).ToString();
                    grpbox.Visibility = Visibility.Visible;




                }
                else
                {
                    grpbox.Visibility = Visibility.Hidden;
                    MessageBox.Show(string.Format("Employee Id {0} does not Exists. ",txtEmpId.Text));


                }

            }
            catch(EmployeeException)
            {

                throw;
            }
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            this.grpbox1.Visibility = Visibility.Visible;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    FirstName = txtFName.Text,
                    Lastname = txtLName.Text,
                    Salary = decimal.Parse(txtSalary.Text),
                    ContactNumber = long.Parse(txtContact.Text),
                    EmployeeID=int.Parse(txtEmpId.Text)
                 


                };
                EmployeeBLL bll = new EmployeeBLL();
                if (bll.EditEmployee(emp))
                {
                    
                    MessageBox.Show("Information saved");
                    grpbox.Visibility = Visibility.Hidden;
                    grpbox1.Visibility = Visibility.Visible;


                }
            }
            catch(EmployeeException)
            {

                throw;
            }

        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int eid = int.Parse(txtEmpId.Text);
                EmployeeBLL bll = new EmployeeBLL();
                if(bll.DeleteEmployee(eid))
                {
                    grpbox.Visibility = Visibility.Visible;
                    MessageBox.Show("Employee details deleted");

                }



            }
            catch(EmployeeException)
            { throw; }


        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Display d = new Display();
            d.Show();
        }
    }
}
