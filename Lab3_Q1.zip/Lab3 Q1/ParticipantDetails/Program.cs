﻿using Lab3_Q1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParticipantDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculatePercentage cp = new CalculatePercentage(300);
            Participant p = new Participant();
            Console.WriteLine(cp.TotalMarks());
            Console.WriteLine(cp.Calculate_Percentage());
           
            Console.ReadLine();
        }
    }
}
