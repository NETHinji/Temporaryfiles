﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Q1
{
    public class Participant
    {
        int _totalMarks;

        public int EmpId;

        //public int EmpId
        //{
        //    get { return _EmpId; }
        //    set { _EmpId = value; }
        //}
        public string Name;

        //public string Name
        //{
        //    get { return _Name; }
        //    set { _Name = value; }
        //}
        static string CompanyName;

        //static string CompanyName
        //{
        //    get { return _CompanyName; }
        //    set { _CompanyName = value; }
        //}
        public int FoundationMarks=50;

        //public int FoundationMarks
        //{
        //    get { return _FoundationMarks; }
        //    set { _FoundationMarks = value; }
        //}
        public int WebBasicMarks=40;

        //public int WebBasicMarks
        //{
        //    get { return _WebBasicMarks; }
        //    set { _WebBasicMarks = value; }
        //}

        public int DotNetMarks=40;

        //public int DotNetMarks
        //{
        //    get { return _DotNetMarks; }
        //    set { _DotNetMarks = value; }
        //}
        //public Participant()
        //{
            
        //}
        //public Participant(int empid,string name,int foundationMarks, int webBasicMarks, int dotNetMarks)
        //{
        //    try
        //    {
        //        if ((foundationMarks > 0 && foundationMarks <= 100) && (webBasicMarks > 0 && webBasicMarks <= 100) && (dotNetMarks > 0 && dotNetMarks <= 100))
        //        {
        //            FoundationMarks = foundationMarks;
        //            WebBasicMarks = webBasicMarks;
        //            DotNetMarks = dotNetMarks;
        //        }
        //        EmpId = empid;
        //        Name = name;
        //    }
        //    catch(Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
            
            
            
            
        //}
        //static Participant()
        //{
        //    CompanyName ="Corporate Unniversity";
        //}

    }
}
