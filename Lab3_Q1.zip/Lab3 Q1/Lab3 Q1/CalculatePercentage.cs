﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Q1
{
    public class CalculatePercentage:Participant
    {
        int _totalMarks;

        public CalculatePercentage(int totalMarks)
        {
            _totalMarks = totalMarks;
        }

        public int TotalMarks()
        {
             _totalMarks = FoundationMarks + WebBasicMarks
                      + DotNetMarks;
            Console.WriteLine(_totalMarks);
            return _totalMarks;
        }
        public int Calculate_Percentage()
        {
            int percentage=_totalMarks /3;
            return percentage;
        }
        
    }
}
