﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{

    class Program
    {
        static void Main(string[] args)
        {
            string Continue;
            do
            {
                
                Console.WriteLine(" 1.Add car\n 2.Modify Details\n 3.search car\n 4. list car\n 5.Delete car");
                int ch;
                Console.Write("\n Enter your choice: ");
                ch = Convert.ToInt32(Console.ReadLine());
                Car c1 = new Car();
                
                switch (ch)
                {
                    case 1:
                        c1.AddCar();
                        break;
                    case 2:
                        c1.ModifyCar();
                        break;
                    case 3:
                        c1.SearchCar();
                        break;
                    case 4:
                        c1.ListCar();
                        break;
                    case 5:
                        c1.DeleteCar();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

                Console.Write("\nDo You Want To Continue? (Y/N) : ");
                Continue = Console.ReadLine();

            } while (Continue != "N" && Continue != "n");
        }
    }
}












