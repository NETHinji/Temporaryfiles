﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    class Car
    {
        public string CarMake { get; set; }
        public string CarModel { get; set; }
        public int CarPrice { get; set; }
        public int CarYear { get; set; }
        List<Car> cars = new List<Car>();
        static public int count=0;
        

        public Car()
        {
            this.CarMake = "ABC";
            this.CarModel = "XYZ";
            this.CarPrice = 1000000;
            this.CarYear = 2000;

        }
        public Car(string CarMake, string CarModel, int CarPrice, int CarYear)
        {
            this.CarMake = CarMake;
            this.CarModel = CarModel;
            this.CarPrice = CarPrice;
            this.CarYear = CarYear;
        }


        public void AddCar()
        {

            try
            {
                Console.Write("Enter Car make: ");
                CarMake = Console.ReadLine();
                Console.Write("Enter Car model: ");
                CarModel = Console.ReadLine();
                Console.Write("Enter Car Price: ");
                CarPrice = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Car Year: ");
                CarYear = Convert.ToInt32(Console.ReadLine());
                Car car = new Car(CarMake, CarModel, CarPrice, CarYear);
                cars.Add(car);
                Console.WriteLine("Car added Succesfully");
            }
            catch (Exception)
            {

                throw;
            }
                     }

        public void ModifyCar()
        {

        }

        public void SearchCar()
        {
            try
            {
                int searchYear = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Found : " + cars.Find(item => item.CarYear == searchYear));
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void ListCar()
        {
            try
            {
                foreach(Car item in cars)
                {
                    Console.WriteLine(item);

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteCar()
        {
            try
            {
                int deleteCarYear;
                Console.WriteLine("Enter Year of car to Delete:");
                deleteCarYear = Convert.ToInt32(Console.ReadLine());

                if (cars.Exists(item => item.CarYear == deleteCarYear))
                    cars.Remove(cars.Find(item => item.CarYear == deleteCarYear));
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override string ToString()
        {
            return "Car make: " + CarMake + "Car model: " + CarModel + "Car Price: " + CarPrice + "Car Year: " + CarYear;
        }
    }
}
