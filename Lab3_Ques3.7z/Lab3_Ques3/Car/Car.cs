﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    class Car
    {
        public string CarMake { get; set; }
        public string CarModel { get; set; }
        public int CarPrice { get; set; }
        public int CarYear { get; set; }
        List<Car> cars = new List<Car>();
        static public int count=0;
        

        public Car()
        {
            this.CarMake = "ABC";
            this.CarModel = "XYZ";
            this.CarPrice = 1000000;
            this.CarYear = 2000;

        }
        public Car(string CarMake, string CarModel, int CarPrice, int CarYear)
        {
            this.CarMake = CarMake;
            this.CarModel = CarModel;
            this.CarPrice = CarPrice;
            this.CarYear = CarYear;
        }


        public void AddCar()
        {

            try
            {
                Console.Write("Enter Car make: ");
                CarMake = Console.ReadLine();
                Console.Write("Enter Car model: ");
                CarModel = Console.ReadLine();
                Console.Write("Enter Car Price: ");
                CarPrice = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Car Year: ");
                CarYear = Convert.ToInt32(Console.ReadLine());
                Car car = new Car(CarMake, CarModel, CarPrice, CarYear);
                cars.Add(car);
                Console.WriteLine("Car added Succesfully");
                count++;
            }
            catch (Exception)
            {

                throw;
            }
                     }

        public void ModifyCar()
        {

        }

        public void SearchCar()
        {
           
        }

        public void ListCar()
        {
            try
            {
                int i = 0;
                while(i<count)
                {

                    Console.Write("Car make: "+cars[i].CarMake);
                   
                    Console.Write("Car model: " + cars[i].CarModel);
                    
                    Console.Write("Enter Car Price: " + cars[i].CarPrice);
                    
                    Console.Write("Enter Car Year: " + cars[i].CarYear);
                   cars.
                    i++;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteCar()
        {
           
                try
                {
                    int deleteCarYear;
                    Console.WriteLine("Enter Year of car to Delete:");
                    deleteCarYear = Convert.ToInt32(Console.ReadLine());






                }

    
            catch (Exception)
            {

                throw;
            }
        }

    }
}
