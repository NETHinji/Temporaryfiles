﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DatabaseFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Training_19Sep18_PuneEntities tr = new Training_19Sep18_PuneEntities();
            Product p = new Product { SerialNumber = 123, ProductName = "oppo", Price = 1500, ProductDescription = "A37", BrandName = "oppo", ProductType = "Xxxxx" };
            tr.Products.Add(p);
            tr.SaveChanges();
           




        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            var product = new List<Product>(
               new Product[]
               {
                    new Product{SerialNumber=123, ProductName="oppo", Price=1500, BrandName="A37",ProductDescription="SSS",ProductType="Mobile"},
                    new Product{SerialNumber=2,  ProductName="vivo", Price=1250,  BrandName="A37",ProductDescription="SSb",ProductType="Laptop"},
                   
               });
            var Result = from a in product
                         where a.ProductType.Equals("Mobile")
                         select new { a.SerialNumber };

            foreach (var Serialnumber in Result)
            {
                dataGrid.ItemsSource = Result.ToList();
            }
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MessageBox.Show(((ProductType)comboBox.SelectedValue).ToString(), "Selected Value");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox.ItemsSource = Enum.GetValues(typeof(ProductType));//Displaying in Combobox
        }
        public enum ProductType { Mobiles,Laptops,Appliances,Accessories};//Declaring Enums
    }
}
