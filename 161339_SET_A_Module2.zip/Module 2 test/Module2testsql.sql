use Training_19Sep18_Pune
create schema Abhishek_161339
go
create table Abhishek_161339.ProductType
(
ProductId int identity(1,1) primary key,
Product_Type nvarchar(250) not null unique
)

drop table Abhishek_161339.Product


insert into Abhishek_161339.ProductType 
values ('Cameras'),('Laptops'),('Mobiles'),('Appliances'),('Acessories')

select * from Abhishek_161339.ProductType

create table Abhishek_161339.Product
(
SerialNumber int identity(1,1) primary key,
ProductName nvarchar(250) unique not null,
[ProductDescription] nvarchar(250) null,
Price money not null,
BrandName nvarchar(250) not null,
Product_Type nvarchar(250) not null foreign key references Abhishek_161339.ProductType(ProductType)
)


insert into Abhishek_161339.Product 
values('Oppo','xxxx',1450,'ddd','Mobile')


select * from  Abhishek_161339.Product

create proc Abhishek_161339.uspAddProduct
(
@pName varchar(25),
@descp varchar(250),
@up money,
@brandname varchar(50),
@producttype varchar(50),
@serialnumber int output
)
as
begin
	insert into Abhishek_161339.Product
	values(@pName,@descp,@up,@brandname,@producttype)
	set @serialnumber = Scope_Identity()
end
create proc Abhishek_161339.uspEditProduct
(
@serialnumber int,
@pName nvarchar(25),
@descp nvarchar(250),
@up money,
@brandname nvarchar(50),
@producttype nvarchar(50)
)
as
begin
	update Abhishek_161339.Product
	set ProductName = @pName,[productDescription]=@descp,
	Price=@up,ProductType=@producttype,BrandName=@brandname
	where SerialNumber = @serialnumber
end

create proc Abhishek_161339.uspSearchProduct
(
@serialnumber int
)
as
begin
	select * from Abhishek_161339.Product
	where SerialNumber = @serialnumber
end

create proc Abhishek_161339.uspGetProducts
as
begin
	select * from Abhishek_161339.Product
end



