﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VijaySalesSolution.BusinessLayer;
using VijaySalesSolution.Entities;
using VijaySalesSolution.Exceptions;

namespace VijaySalesSolution
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product
                {
                    ProductName = txtproductname.Text,
                    ProductDescription = txtproductdescription.Text,
                   Price = int.Parse(txtprice.Text),
                    BrandName = (txtbrandname.Text),
                    ProductType = (comboBox.SelectedValue.ToString())
                };
                ProductBL pb = new ProductBL();
                int serialnumber = pb.AddProduct(p);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", serialnumber),
                    "Vijay Sales Management System");
            }
            catch (VijaySalesException ex)
            {
                MessageBox.Show(ex.Message, "Vijay Sales Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Vijay Sales Management System");
            }
            
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MessageBox.Show(((producttype)comboBox.SelectedValue).ToString(), "Selected Value");

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox.ItemsSource = Enum.GetValues(typeof(producttype));
        }
        public enum producttype
        { Mobiles, cameras, Laptops,Appliances,Accesories }
    }
}
