﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VijaySalesSolution.Entities;
using VijaySalesSolution.Exceptions;

namespace VijaySalesSolution.DataAccessLayer
{
    public class VijaySalesDal
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pboj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;

        static VijaySalesDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public VijaySalesDal()
        {
            con = new SqlConnection(conStr);

        }
        public int AddProduct(Product pboj)
        {
            int serialnumber = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand("Abhishek_161339.uspAddProduct", con);
                //cmd.CommandText = "Abhishek.uspAddProduct";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@serialnumber", SqlDbType.Int);
                cmd.Parameters["@serialnumber"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@pName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descp", pboj.ProductDescription);
                cmd.Parameters.AddWithValue("@up", pboj.Price);
                cmd.Parameters.AddWithValue("@brandname", pboj.BrandName);
                cmd.Parameters.AddWithValue("@producttype", pboj.ProductType);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                serialnumber = int.Parse(cmd.Parameters["@serialnumber"].Value.ToString());
            }
            catch (VijaySalesException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return serialnumber;
        }
        public Product Search(int serialnumber)
        {
            Product p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand("Abhishek_161339.uspSearchProduct", con);
                //cmd.CommandText = "Geetha.uspSearchProduct";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@serialnumber", serialnumber);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Product
                    {
                        SerialNumber = int.Parse(dr["serialnumber"].ToString()),
                        ProductName = dr["ProductName"].ToString(),
                        ProductDescription = dr["Description"].ToString(),
                        Price = int.Parse(dr["Unitprice"].ToString()),
                        BrandName = (dr["Stock"].ToString()),
                        ProductType = (dr["Category"].ToString())
                    };
                    dr.Close();
                }
            }
            catch (VijaySalesException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }
        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Abhishek_161339.uspGetProducts";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (VijaySalesException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        public DataTable GetCategories()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand("Abhishek_161339.uspGetCategories", con);
                //cmd.CommandText = "Abhishek.uspGetCategories";
                //cmd.Connection = con;
                //cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new VijaySalesException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new VijaySalesException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
