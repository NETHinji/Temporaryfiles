﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VijaySalesSolution.DataAccessLayer;
using VijaySalesSolution.Entities;
using VijaySalesSolution.Exceptions;

namespace VijaySalesSolution.BusinessLayer
{
    public class ProductBL
    {
        public int AddProduct(Product pobj)
        {
            try
            {
                VijaySalesDal pd = new VijaySalesDal();
                return pd.AddProduct(pobj);
            }
            catch (VijaySalesException)
            {
                throw;
            }

        }
        public Product Search(int productId)
        {
            try
            {
                VijaySalesDal pd = new VijaySalesDal();
                return pd.Search(productId);
            }
            catch (VijaySalesException)
            {
                throw;
            }
        }
        public DataTable Display()
        {
            try
            {
                VijaySalesDal pd = new VijaySalesDal();
                return pd.Display();
            }
            catch (VijaySalesException)
            {
                throw;
            }
        }
        public DataTable GetCategories()
        {
            try
            {
                VijaySalesDal pd = new VijaySalesDal();
                return pd.GetCategories();
            }
            catch (VijaySalesException)
            {
                throw;
            }
        }
    }
}
